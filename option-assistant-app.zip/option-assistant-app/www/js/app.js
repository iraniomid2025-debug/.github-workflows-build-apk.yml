/*
  app.js — دستیار آپشن
  ساختار ۵ تبی: داشبورد | بازار زنده | پرتفوی (موقعیت‌ها+معاملات) | دستیار (فرصت‌ها+ترکیبی+ابزار) | تنظیمات
*/

const APP = (function () {
  let currentScreen = "dashboard";
  let portfolioSubTab = "positions"; // positions | trades
  let assistantSubTab = "opps";      // opps | combo | tools
  let toolsTab = "panj";

  const screens = {
    dashboard: { icon: "📊", label: "داشبورد" },
    market: { icon: "📡", label: "بازار زنده" },
    portfolio: { icon: "📁", label: "پرتفوی" },
    assistant: { icon: "🧭", label: "دستیار" },
    settings: { icon: "⚙️", label: "تنظیمات" },
  };

  function fmt(n, d = 0) {
    if (n === null || n === undefined || isNaN(n)) return "—";
    return Number(n).toLocaleString("en-US", { maximumFractionDigits: d });
  }
  function todayStr() {
    return new Date().toISOString().slice(0, 10);
  }

  // ---------------- تبدیل میلادی به شمسی (جلالی) - الگوریتم استاندارد jalaali ----------------
  function jDiv(a, b) { return ~~(a / b); }
  function jMod(a, b) { return a - ~~(a / b) * b; }
  function g2d(gy, gm, gd) {
    let d = jDiv((gy + jDiv(gm - 8, 6) + 100100) * 1461, 4)
          + jDiv(153 * jMod(gm + 9, 12) + 2, 5)
          + gd - 34840408;
    d = d - jDiv(jDiv(gy + 100100 + jDiv(gm - 8, 6), 100) * 3, 4) + 752;
    return d;
  }
  function jalCal(jy) {
    const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
    const bl = breaks.length;
    const gy = jy + 621;
    let leapJ = -14, jp = breaks[0], jm, jump, n, i;
    for (i = 1; i < bl; i += 1) {
      jm = breaks[i];
      jump = jm - jp;
      if (jy < jm) break;
      leapJ = leapJ + jDiv(jump, 33) * 8 + jDiv(jMod(jump, 33), 4);
      jp = jm;
    }
    n = jy - jp;
    leapJ = leapJ + jDiv(n, 33) * 8 + jDiv(jMod(n, 33) + 3, 4);
    if (jMod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
    const leapG = jDiv(gy, 4) - jDiv((jDiv(gy, 100) + 1) * 3, 4) - 150;
    const march = 20 + leapJ - leapG;
    return { march };
  }
  function d2g(jdn) {
    let j = 4 * jdn + 139361631;
    j = j + jDiv(jDiv(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
    const i = jDiv(jMod(j, 1461), 4) * 5 + 308;
    const gd = jDiv(jMod(i, 153), 5) + 1;
    const gm = jMod(jDiv(i, 153), 12) + 1;
    const gy = jDiv(j, 1461) - 100100 + jDiv(8 - gm, 6);
    return { gy, gm, gd };
  }
  function d2j(jdn) {
    const gInfo = d2g(jdn);
    let jy = gInfo.gy - 621;
    const r = jalCal(jy);
    const jdn1f = g2d(gInfo.gy, 3, r.march);
    let k = jdn - jdn1f, jm, jd;
    if (k >= 0) {
      if (k <= 185) {
        jm = 1 + jDiv(k, 31);
        jd = jMod(k, 31) + 1;
        return { jy, jm, jd };
      } else {
        k -= 186;
      }
    } else {
      jy -= 1;
      k += 179;
    }
    jm = 7 + jDiv(k, 30);
    jd = jMod(k, 30) + 1;
    return { jy, jm, jd };
  }
  function toJalali(gy, gm, gd) {
    const jdn = g2d(gy, gm, gd);
    const r = d2j(jdn);
    return [r.jy, r.jm, r.jd];
  }
  function jalaliStr(dateStr){
    if(!dateStr) return "-";
    const d = new Date(dateStr + (dateStr.length<=10 ? "T00:00:00" : ""));
    if(isNaN(d.getTime())) return dateStr;
    const [jy,jm,jd] = toJalali(d.getFullYear(), d.getMonth()+1, d.getDate());
    const months = ["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
    return `${jd} ${months[jm]} ${jy}`;
  }
  function jalaliStrShort(dateStr){
    if(!dateStr) return "-";
    const d = new Date(dateStr + (dateStr.length<=10 ? "T00:00:00" : ""));
    if(isNaN(d.getTime())) return dateStr;
    const [jy,jm,jd] = toJalali(d.getFullYear(), d.getMonth()+1, d.getDate());
    return `${jy}/${String(jm).padStart(2,'0')}/${String(jd).padStart(2,'0')}`;
  }
  function expiryPillClass(days){
    if(days<=2) return "critical";
    if(days<=7) return "warning";
    if(days<=15) return "notice";
    return "safe";
  }
  function expiryPillHtml(expiryDate){
    if(!expiryDate) return "";
    const days = OPP.daysBetween(expiryDate);
    return `<span class="exp-pill ${expiryPillClass(days)}">⏱ ${days} روز</span>`;
  }
  function startClock(){
    const el = document.getElementById("clockPill");
    const dateEl = document.getElementById("datePill");
    if(!el) return;
    const days = ["یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"];
    const tick = () => {
      const now = new Date();
      el.textContent = now.toLocaleTimeString("fa-IR",{hour:'2-digit',minute:'2-digit',second:'2-digit'});
      if(dateEl){
        const [jy,jm,jd] = toJalali(now.getFullYear(), now.getMonth()+1, now.getDate());
        const months = ["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
        dateEl.textContent = `${days[now.getDay()]} ${jd} ${months[jm]} ${jy}`;
      }
    };
    tick();
    setInterval(tick, 1000);
  }
  function applyTheme(theme){
    document.documentElement.setAttribute("data-theme", theme);
    const meta = document.querySelector('meta[name="theme-color"]');
    if(meta) meta.setAttribute("content", theme === "dark" ? "#0a0d11" : "#f4f6f8");
  }

  // ---------------- Navigation ----------------
  function renderNav() {
    const nav = document.getElementById("bottomNav");
    let alertCount = 0;
    try {
      const o = OPP.scanAll();
      alertCount = o.spreads.length + o.yieldJumps.length + o.belowTarget.length + o.goodJumps.length + o.expiries.filter(e=>e.level!=='notice').length;
    } catch(e){}
    nav.innerHTML = Object.keys(screens)
      .map(
        (key) => `
        <button class="${key === currentScreen ? "active" : ""}" data-screen="${key}">
          <span class="ic">${screens[key].icon}${(key==='assistant' && alertCount>0) ? '<span class="badge-dot"></span>':''}</span>
          <span>${screens[key].label}</span>
        </button>`
      )
      .join("");
    nav.querySelectorAll("button").forEach((btn) => {
      btn.addEventListener("click", () => goTo(btn.dataset.screen));
    });
  }

  function goTo(screen) {
    if (currentScreen === "market" && screen !== "market" && marketAutoTimer) {
      clearInterval(marketAutoTimer);
      marketAutoTimer = null;
    }
    currentScreen = screen;
    renderNav();
    document.getElementById("headerSub").textContent = screens[screen].label;
    const renderers = {
      dashboard: renderDashboard,
      market: renderMarket,
      portfolio: renderPortfolio,
      assistant: renderAssistant,
      settings: renderSettings,
    };
    renderers[screen]();
  }

  function handleHardwareBack() {
    // اگر مودالی باز است، فقط آن را ببند
    if (document.getElementById("modalOverlay")) {
      closeModal();
      return;
    }
    // از هر تبی، یک برگشت می‌برد به داشبورد
    if (currentScreen !== "dashboard") {
      goTo("dashboard", true);
      return;
    }
    // از داشبورد، برگشت یعنی خروج از اپ
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
      window.Capacitor.Plugins.App.exitApp();
    }
  }

  // ================= داشبورد =================
  function assistantMessage(positions, opps){
    const totalAlerts = opps.spreads.length + opps.yieldJumps.length + opps.belowTarget.length + opps.goodJumps.length;
    const critExp = opps.expiries.filter(e=>e.level==='critical').length;
    if(positions.length === 0){
      return "هنوز پرتفوی خالیه — از تب «پرتفوی» شروع کن، سهام و قراردادهاتو ثبت کن تا از همینجا برات فرصت‌ها رو پیدا کنم.";
    }
    if(critExp > 0){
      return `⚠️ <b>${critExp} قرارداد</b> کمتر از ۲ روز تا سررسید دارن — همین الان به تب «دستیار» سر بزن.`;
    }
    if(opps.goodJumps.length > 0){
      return `🔥 <b>${opps.goodJumps.length} فرصت جامپ خوب</b> بالای آستانه‌ات پیدا کردم — برو تب «دستیار» ببین.`;
    }
    if(totalAlerts > 0){
      return `الان <b>${totalAlerts} فرصت/هشدار</b> برات پیدا کردم (جامپ، تیک‌سود یا زیر آستانه). برو تب «دستیار» ببین.`;
    }
    return "همه‌چی آرومه — هیچ هشدار فوری‌ای نیست. قیمت‌های بازار زنده رو تازه نگه دار تا فرصت‌ها رو از دست ندی.";
  }

  function renderDashboard() {
    const positions = DB.getPositions();
    const opps = OPP.scanAll();
    const stocks = positions.filter((p) => p.type === "stock");
    const options = positions.filter((p) => p.type === "option");
    const totalAlerts = opps.spreads.length + opps.yieldJumps.length + opps.belowTarget.length + opps.goodJumps.length;
    const upcomingExp = opps.expiries.slice(0,5);

    const main = document.getElementById("main");
    main.innerHTML = `
      <div class="assistant-card">
        <div class="a-title">🧭 دستیار آپشن</div>
        <div class="a-msg">${assistantMessage(positions, opps)}</div>
      </div>

      <div class="stat-strip">
        <div class="s"><div class="n">${stocks.length}</div><div class="l">موقعیت سهم</div></div>
        <div class="s"><div class="n">${options.length}</div><div class="l">قرارداد باز</div></div>
        <div class="s"><div class="n" style="color:${totalAlerts>0?'var(--amber)':'var(--green)'}">${totalAlerts}</div><div class="l">هشدار فعال</div></div>
      </div>

      ${upcomingExp.length ? `
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot" style="background:var(--red)"></span> نزدیک‌ترین سررسیدها</div>
          <span class="count-pill">${upcomingExp.length}</span>
        </div>
        ${upcomingExp.map(e => `
          <div class="list-row">
            <div class="lr-main">
              <div class="lr-symbol">${e.position.symbol} <span class="chip ${e.position.side==='sold'?'sold':'bought'}">${e.position.side==='sold'?'فروخته‌شده':'خریداری‌شده'}</span></div>
              <div class="lr-meta">اعمال ${fmt(e.position.strike)} · ${jalaliStrShort(e.position.expiryDate)}</div>
            </div>
            <div class="lr-right">${expiryPillHtml(e.position.expiryDate)}</div>
          </div>
        `).join("")}
      </div>` : ""}

      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot"></span> فرصت‌های فوری</div>
          <span class="count-pill">${totalAlerts} مورد</span>
        </div>
        ${renderOppList(opps, true)}
      </div>

      <div class="panel">
        <div class="panel-title"><span class="dot" style="background:var(--green)"></span> دسترسی سریع</div>
        <div class="btn-row">
          <button class="btn" id="qAddPos">+ موقعیت جدید</button>
          <button class="btn secondary" id="qAddTrade">+ ثبت معامله</button>
        </div>
      </div>
    `;
    document.getElementById("qAddPos").onclick = () => openPositionModal();
    document.getElementById("qAddTrade").onclick = () => openTradeModal();
  }

  function renderOppList(opps, limit) {
    const all = [
      ...opps.goodJumps.map((o) => ({
        cls: "good",
        tag: "جامپ خوب",
        title: `🔥 ${o.message}`,
        detail: `سرمایه پایه جدید: ${fmt(o.calc.newBase)} ریال · اختلاف پرمیوم: ${fmt(o.calc.spread)} ریال`,
      })),
      ...opps.spreads.map((o) => ({
        cls: "good",
        tag: "تیک‌سود",
        title: `⚡ تیک‌سود اسپرد — ${o.symbol} (اعمال ${o.strike})`,
        detail: `${o.action === "buy_near_sell_far" ? "بخر نزدیک / بفروش دور" : "بفروش نزدیک / بخر دور"} · انحراف از تعادل: ${fmt(o.deviation,1)} ریال · سود بالقوه ~${fmt(o.potentialRial)} ریال`,
      })),
      ...opps.yieldJumps.map((o) => ({
        cls: "",
        tag: "جامپ",
        title: `🔁 نیاز به جامپ بازدهی`,
        detail: o.message,
      })),
      ...opps.belowTarget.map((o) => ({
        cls: "",
        tag: "بررسی",
        title: `📉 زیر آستانه سود`,
        detail: o.message,
      })),
      ...((opps.expiries||[]).map((o) => ({
        cls: o.level === "critical" ? "critical" : "",
        tag: `${o.daysLeft} روز`,
        title: `⏱ سررسید نزدیک — ${o.position.symbol} (اعمال ${o.position.strike})`,
        detail: `این قرارداد ${o.daysLeft} روز دیگر سررسید می‌شود — تصمیم جامپ/اعمال را از الان آماده کنید.`,
      }))),
    ];
    if (all.length === 0) return `<div class="empty-state"><span class="es-ic">🌤</span>فعلاً فرصت خاصی شناسایی نشده — قیمت‌های بازار زنده و پرتفوی را به‌روز نگه دارید.</div>`;
    const list = limit ? all.slice(0, 4) : all;
    return list
      .map(
        (o) => `<div class="opp-card ${o.cls}"><div style="flex:1"><div class="opp-title">${o.title}</div><div class="opp-detail">${o.detail}</div></div>${o.tag?`<span class="opp-tag">${o.tag}</span>`:""}</div>`
      )
      .join("");
  }

  // ================= بازار زنده =================
  let marketAutoTimer = null;
  function renderMarket() {
    if (marketAutoTimer) { clearInterval(marketAutoTimer); marketAutoTimer = null; }
    const list = DB.getWatchlist();
    const main = document.getElementById("main");
    main.innerHTML = `
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot"></span> جستجوی نماد (سهام و اختیار معامله)</div></div>
        <div class="field-row full" style="margin-bottom:8px;">
          <input type="text" id="wSearch" placeholder="نام نماد را تایپ کنید (مثلا خودرو)" style="direction:rtl;text-align:right;">
        </div>
        <div id="wSearchResults"></div>
      </div>

      <div class="panel">
        <div class="panel-title">
          <div class="panel-title-l"><span class="dot" style="background:var(--green)"></span> دیده‌بان زنده <span class="exp-pill safe" style="margin-right:4px;" id="autoRefreshBadge">🔴 خودکار</span></div>
          <button class="btn secondary" id="wRefreshAll" style="width:auto;padding:6px 12px;font-size:11px;">🔄 دستی</button>
        </div>
        <div id="wList">
          ${list.length === 0 ? `<div class="empty-state"><span class="es-ic">📡</span>نمادی اضافه نشده. از جستجوی بالا استفاده کنید.</div>` : list.map(watchRow).join("")}
        </div>
      </div>
    `;

    let searchTimeout;
    document.getElementById("wSearch").addEventListener("input", (e) => {
      clearTimeout(searchTimeout);
      const term = e.target.value.trim();
      if (term.length < 2) {
        document.getElementById("wSearchResults").innerHTML = "";
        return;
      }
      searchTimeout = setTimeout(async () => {
        const results = await TSETMC.searchInstrument(term);
        document.getElementById("wSearchResults").innerHTML = results
          .slice(0, 8)
          .map(
            (r) => `<div class="list-row" style="cursor:pointer" data-inscode="${r.insCode}" data-symbol="${r.symbol}">
              <div class="lr-main"><div class="lr-symbol">${r.symbol}</div><div class="lr-meta">${r.name}</div></div>
              <div class="lr-right"><span class="chip">+ افزودن</span></div>
            </div>`
          )
          .join("") || `<div class="empty-state">چیزی پیدا نشد.</div>`;
        document.querySelectorAll("#wSearchResults .list-row").forEach((row) => {
          row.onclick = () => {
            DB.addWatch({ insCode: row.dataset.inscode, symbol: row.dataset.symbol });
            document.getElementById("wSearch").value = "";
            document.getElementById("wSearchResults").innerHTML = "";
            renderMarket();
          };
        });
      }, 400);
    });

    async function doAutoRefresh(silent) {
      const curList = DB.getWatchlist();
      if (curList.length === 0) return;
      const badge = document.getElementById("autoRefreshBadge");
      if (badge && !silent) badge.textContent = "🔄 در حال دریافت";
      await TSETMC.refreshWatchlist(curList, (insCode, info) => {
        const old = curList.find((x) => x.insCode === insCode);
        const oldPrice = old ? old.lastPrice : null;
        DB.updateWatchPrice(insCode, info);
        const rowEl = document.getElementById("wrow-" + insCode);
        if (rowEl && info.lastPrice != null && oldPrice != null && info.lastPrice !== oldPrice) {
          rowEl.outerHTML = watchRow(Object.assign({}, old, info), true);
        } else if (rowEl) {
          const fresh = DB.getWatchlist().find((x) => x.insCode === insCode);
          if (fresh) rowEl.outerHTML = watchRow(fresh);
        }
      });
      if (badge) badge.textContent = "🔴 خودکار";
    }

    document.getElementById("wRefreshAll").onclick = () => doAutoRefresh(false);
    document.querySelectorAll(".wRemove").forEach((b) => {
      b.onclick = (e) => {
        e.stopPropagation();
        DB.removeWatch(b.dataset.inscode);
        renderMarket();
      };
    });

    // رفرش خودکار هر ۱۵ ثانیه تا وقتی کاربر روی همین صفحه است
    marketAutoTimer = setInterval(() => doAutoRefresh(true), 15000);
    doAutoRefresh(true);
  }

  function watchRow(w, flash) {
    const rowId = `wrow-${w.insCode}`;
    if (w.fetchError) {
      return `
      <div class="list-row" id="${rowId}">
        <div class="lr-main">
          <div class="lr-symbol">${w.symbol}</div>
          <div class="lr-meta" style="color:var(--red);">خطا: ${w.fetchError}</div>
        </div>
        <button class="wRemove" data-inscode="${w.insCode}" style="background:none;border:none;color:var(--text-faint);font-size:16px;margin-right:6px;">✕</button>
      </div>`;
    }
    if (w.lastPrice == null) {
      return `
      <div class="list-row" id="${rowId}">
        <div class="lr-main">
          <div class="lr-symbol">${w.symbol}</div>
          <div class="lr-meta">در حال دریافت اولین قیمت...</div>
        </div>
        <button class="wRemove" data-inscode="${w.insCode}" style="background:none;border:none;color:var(--text-faint);font-size:16px;margin-right:6px;">✕</button>
      </div>`;
    }
    const change = w.priceChange || 0;
    const changePct = w.priceYesterday ? (change / w.priceYesterday) * 100 : 0;
    const changeCls = change > 0 ? "up" : change < 0 ? "down" : "";
    const arrow = change > 0 ? "▲" : change < 0 ? "▼" : "—";
    const flashCls = flash ? (change >= 0 ? "flash-up" : "flash-down") : "";
    return `
      <div class="list-row ${flashCls}" id="${rowId}" style="align-items:flex-start;">
        <div class="lr-main">
          <div class="lr-symbol">${w.symbol}</div>
          <div class="lr-meta">دیروز ${fmt(w.priceYesterday)} · بازه ${fmt(w.priceMin)}–${fmt(w.priceMax)}</div>
          <div class="lr-meta">${w.updatedAt ? "به‌روز: " + new Date(w.updatedAt).toLocaleTimeString("fa-IR") : ""}</div>
        </div>
        <div class="lr-right">
          <div class="lr-price ${changeCls}">${fmt(w.lastPrice)}</div>
          <div class="lr-change ${changeCls}">${arrow} ${fmt(Math.abs(change))} (${fmt(Math.abs(changePct),1)}٪)</div>
          <div class="lr-meta">پایانی ${fmt(w.closingPrice)}</div>
        </div>
        <button class="wRemove" data-inscode="${w.insCode}" style="background:none;border:none;color:var(--text-faint);font-size:16px;margin-right:2px;">✕</button>
      </div>`;
  }

  // ================= پرتفوی (موقعیت‌ها + معاملات) =================
  function renderPortfolio() {
    const main = document.getElementById("main");
    main.innerHTML = `
      <div class="segmented">
        <button class="seg-btn ${portfolioSubTab==='positions'?'on':''}" data-pt="positions">موقعیت‌ها</button>
        <button class="seg-btn ${portfolioSubTab==='trades'?'on':''}" data-pt="trades">دفتر معاملات</button>
      </div>
      <div id="portfolioBody"></div>
    `;
    document.querySelectorAll(".seg-btn[data-pt]").forEach(b=>{
      b.onclick = () => { portfolioSubTab = b.dataset.pt; renderPortfolio(); };
    });
    if(portfolioSubTab === "positions") renderPositionsBody();
    else renderTradesBody();
  }

  function renderPositionsBody(){
    const positions = DB.getPositions();
    document.getElementById("portfolioBody").innerHTML = `
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot"></span> موقعیت‌های باز</div><span class="count-pill">${positions.length}</span></div>
        <div id="posList">
          ${positions.length === 0 ? `<div class="empty-state"><span class="es-ic">📁</span>هنوز موقعیتی ثبت نشده. با دکمه + شروع کنید.</div>` : positions.map(posRow).join("")}
        </div>
      </div>
      <button class="fab" id="fabAddPos">+</button>
    `;
    document.getElementById("fabAddPos").onclick = () => openPositionModal();
    positions.forEach((p) => {
      const el = document.getElementById("row-" + p.id);
      if (el) el.onclick = () => openPositionModal(p);
    });
  }

  function posRow(p) {
    const isOption = p.type === "option";
    const chipCls = isOption ? (p.side === "sold" ? "sold" : "bought") : (p.isBait ? "bait" : "stock");
    const chipLabel = isOption ? (p.side === "sold" ? "فروخته‌شده" : "خریداری‌شده") : (p.isBait ? "طعمه" : "سهم");
    const metaLine = isOption
      ? `اعمال ${fmt(p.strike)} · پرمیوم ${fmt(p.premium)} · سررسید ${jalaliStrShort(p.expiryDate)}`
      : `${fmt(p.qty)} سهم @ ${fmt(p.avgPrice)}`;
    return `
      <div class="list-row" id="row-${p.id}" style="cursor:pointer">
        <div class="lr-main">
          <div class="lr-symbol">${p.symbol} <span class="chip ${chipCls}">${chipLabel}</span> ${isOption ? expiryPillHtml(p.expiryDate) : ""}</div>
          <div class="lr-meta">${metaLine}</div>
        </div>
        <div class="lr-right">
          <div class="lr-price">${fmt(p.qty)}</div>
          <div class="lr-change">تعداد</div>
        </div>
      </div>`;
  }

  function openPositionModal(existing) {
    const p = existing || { type: "stock", symbol: "", qty: "", avgPrice: "", isBait: false };
    showModal(
      existing ? "ویرایش موقعیت" : "موقعیت جدید",
      `
      <div class="segmented">
        <button class="seg-btn ${p.type === "stock" ? "on" : ""}" data-type="stock">سهم پایه</button>
        <button class="seg-btn ${p.type === "option" ? "on" : ""}" data-type="option">قرارداد آپشن</button>
      </div>
      <div class="field-row full"><label>نماد</label><input type="text" id="m_symbol" value="${p.symbol || ""}" placeholder="مثلا خودرو" style="direction:rtl;text-align:right;"></div>
      <div id="stockFields" class="${p.type === "option" ? "hidden" : ""}">
        <div class="field-row"><label>تعداد سهم</label><input type="text" id="m_qty" value="${p.qty || ""}"></div>
        <div class="field-row"><label>قیمت خرید (ریال)</label><input type="text" id="m_avgPrice" value="${p.avgPrice || ""}"></div>
        <div class="field-row"><label>سهام طعمه است؟</label>
          <select id="m_isBait"><option value="0" ${!p.isBait?"selected":""}>خیر</option><option value="1" ${p.isBait?"selected":""}>بله</option></select>
        </div>
        <div class="divider"></div>
        <div class="field-row full"><label style="font-weight:700;">فرصت خرید ترکیبی (اختیاری)</label></div>
        <div class="field-row"><label>اعمال قرارداد کاندید</label><input type="text" id="m_comboStrike" value="${p.comboStrike || ""}"></div>
        <div class="field-row"><label>پرمیوم قرارداد کاندید</label><input type="text" id="m_comboPremium" value="${p.comboPremium || ""}"></div>
      </div>
      <div id="optionFields" class="${p.type === "stock" ? "hidden" : ""}">
        <div class="field-row"><label>نوع موقعیت</label>
          <select id="m_side"><option value="sold" ${p.side==="sold"?"selected":""}>فروخته‌شده</option><option value="bought" ${p.side==="bought"?"selected":""}>خریداری‌شده</option></select>
        </div>
        <div class="field-row"><label>قیمت اعمال</label><input type="text" id="m_strike" value="${p.strike || ""}"></div>
        <div class="field-row"><label>پرمیوم اولیه</label><input type="text" id="m_premium" value="${p.premium || ""}"></div>
        <div class="field-row"><label>پرمیوم روز (اختیاری)</label><input type="text" id="m_currentPremium" value="${p.currentPremium || ""}"></div>
        <div class="field-row"><label>تعداد قرارداد</label><input type="text" id="m_qty2" value="${p.qty || ""}"></div>
        <div class="field-row"><label>اندازه قرارداد</label><input type="text" id="m_contractSize" value="${p.contractSize || 1000}"></div>
        <div class="field-row"><label>سررسید</label><input type="date" id="m_expiry" value="${p.expiryDate || ""}"></div>
        <div class="note" id="m_expiryJalali" style="margin-top:-6px;padding-top:0;border-top:none;text-align:left;">${p.expiryDate ? jalaliStr(p.expiryDate) : ""}</div>
        <div class="field-row"><label>قیمت سهم پایه روز</label><input type="text" id="m_spot" value="${p.spot || ""}"></div>
        <div class="field-row"><label>نقطه تعادل (تیک‌سود، اختیاری)</label><input type="text" id="m_equilibrium" value="${p.equilibrium || ""}"></div>
        <div class="divider"></div>
        <div class="field-row full"><label style="font-weight:700;">کاندید جامپ بازدهی (اختیاری، برای هشدار خودکار)</label></div>
        <div class="field-row"><label>پرمیوم قرارداد سررسید بعدی</label><input type="text" id="m_jumpPremium" value="${p.jumpCandidatePremium || ""}"></div>
        <div class="field-row"><label>روز کل تا آن سررسید</label><input type="text" id="m_jumpDays" value="${p.jumpCandidateDays || ""}"></div>
      </div>
      <div class="field-row full"><label>یادداشت</label><textarea id="m_notes">${p.notes || ""}</textarea></div>
      <div class="btn-row">
        <button class="btn" id="m_save">ذخیره</button>
        ${existing ? `<button class="btn danger" id="m_delete">حذف</button>` : ""}
      </div>
      `
    );

    let curType = p.type;
    document.getElementById("m_expiry").addEventListener("input", (e)=>{
      document.getElementById("m_expiryJalali").textContent = e.target.value ? jalaliStr(e.target.value) : "";
    });
    document.querySelectorAll(".seg-btn[data-type]").forEach((b) => {
      b.onclick = () => {
        document.querySelectorAll(".seg-btn[data-type]").forEach((x) => x.classList.remove("on"));
        b.classList.add("on");
        curType = b.dataset.type;
        document.getElementById("stockFields").classList.toggle("hidden", curType !== "stock");
        document.getElementById("optionFields").classList.toggle("hidden", curType !== "option");
      };
    });

    document.getElementById("m_save").onclick = () => {
      const obj = {
        id: existing ? existing.id : null,
        type: curType,
        symbol: val("m_symbol"),
        notes: val("m_notes"),
      };
      if (curType === "stock") {
        obj.qty = numVal("m_qty");
        obj.avgPrice = numVal("m_avgPrice");
        obj.isBait = document.getElementById("m_isBait").value === "1";
        obj.comboStrike = numVal("m_comboStrike") || null;
        obj.comboPremium = numVal("m_comboPremium") || null;
      } else {
        obj.side = document.getElementById("m_side").value;
        obj.strike = numVal("m_strike");
        obj.premium = numVal("m_premium");
        obj.currentPremium = numVal("m_currentPremium") || numVal("m_premium");
        obj.qty = numVal("m_qty2");
        obj.contractSize = numVal("m_contractSize") || 1000;
        obj.expiryDate = document.getElementById("m_expiry").value;
        obj.spot = numVal("m_spot");
        obj.equilibrium = numVal("m_equilibrium");
        obj.jumpCandidatePremium = numVal("m_jumpPremium") || null;
        obj.jumpCandidateDays = numVal("m_jumpDays") || null;
      }
      DB.savePosition(obj);
      closeModal();
      renderPositionsBody();
      renderNav();
      scheduleExpiryNotifications();
    };
    if (existing) {
      document.getElementById("m_delete").onclick = () => {
        DB.deletePosition(existing.id);
        closeModal();
        renderPositionsBody();
        renderNav();
        scheduleExpiryNotifications();
      };
    }
  }

  function renderTradesBody() {
    const trades = DB.getTrades();
    document.getElementById("portfolioBody").innerHTML = `
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot"></span> دفتر معاملات</div><span class="count-pill">${trades.length}</span></div>
        <div id="tradeList">
          ${trades.length === 0 ? `<div class="empty-state"><span class="es-ic">📝</span>هنوز معامله‌ای ثبت نشده.</div>` : trades.map(tradeRow).join("")}
        </div>
      </div>
      <button class="fab" id="fabAddTrade">+</button>
    `;
    document.getElementById("fabAddTrade").onclick = () => openTradeModal();
    trades.forEach((t) => {
      const el = document.getElementById("trow-" + t.id);
      if (el) el.onclick = () => openTradeModal(t);
    });
  }

  const tradeTypeLabels = {
    buy_stock: "خرید سهم",
    sell_stock: "فروش سهم",
    sell_option: "فروش قرارداد",
    buy_option: "خرید/آفست قرارداد",
    jump_yield: "جامپ بازدهی",
    jump_mgmt: "جامپ مدیریتی",
    tick_sood: "تیک‌سود",
    combo: "معامله ترکیبی",
  };

  function tradeRow(t) {
    return `
      <div class="list-row" id="trow-${t.id}" style="cursor:pointer">
        <div class="lr-main">
          <div class="lr-symbol">${t.symbol} <span class="chip">${tradeTypeLabels[t.type] || t.type}</span></div>
          <div class="lr-meta mono">${jalaliStrShort(t.date)} · اعمال ${fmt(t.strike)} · قیمت ${fmt(t.price)}</div>
        </div>
        <div class="lr-right">
          <div class="lr-price">${fmt(t.qty)}</div>
          <div class="lr-change">تعداد</div>
        </div>
      </div>`;
  }

  function openTradeModal(existing) {
    const t = existing || { date: todayStr(), type: "sell_option" };
    showModal(
      existing ? "ویرایش معامله" : "ثبت معامله جدید",
      `
      <div class="field-row"><label>تاریخ</label><input type="date" id="t_date" value="${t.date}"></div>
      <div class="note" id="t_dateJalali" style="margin-top:-6px;padding-top:0;border-top:none;text-align:left;">${jalaliStr(t.date)}</div>
      <div class="field-row"><label>نوع معامله</label>
        <select id="t_type">
          ${Object.keys(tradeTypeLabels).map(k=>`<option value="${k}" ${t.type===k?"selected":""}>${tradeTypeLabels[k]}</option>`).join("")}
        </select>
      </div>
      <div class="field-row full"><label>نماد</label><input type="text" id="t_symbol" value="${t.symbol||""}" style="direction:rtl;text-align:right;"></div>
      <div class="field-row"><label>قیمت اعمال (اگر آپشن است)</label><input type="text" id="t_strike" value="${t.strike||""}"></div>
      <div class="field-row"><label>قیمت/پرمیوم معامله</label><input type="text" id="t_price" value="${t.price||""}"></div>
      <div class="field-row"><label>تعداد</label><input type="text" id="t_qty" value="${t.qty||""}"></div>
      <div class="field-row full"><label>یادداشت</label><textarea id="t_notes">${t.notes||""}</textarea></div>
      <div class="btn-row">
        <button class="btn" id="t_save">ذخیره</button>
        ${existing ? `<button class="btn danger" id="t_delete">حذف</button>` : ""}
      </div>
      `
    );
    document.getElementById("t_date").addEventListener("input", (e)=>{
      document.getElementById("t_dateJalali").textContent = e.target.value ? jalaliStr(e.target.value) : "";
    });
    document.getElementById("t_save").onclick = () => {
      const obj = {
        id: existing ? existing.id : null,
        date: document.getElementById("t_date").value,
        type: document.getElementById("t_type").value,
        symbol: val("t_symbol"),
        strike: numVal("t_strike"),
        price: numVal("t_price"),
        qty: numVal("t_qty"),
        notes: val("t_notes"),
      };
      DB.saveTrade(obj);
      closeModal();
      renderTradesBody();
    };
    if (existing) {
      document.getElementById("t_delete").onclick = () => {
        DB.deleteTrade(existing.id);
        closeModal();
        renderTradesBody();
      };
    }
  }

  // ================= دستیار (فرصت‌ها + ترکیبی + ابزار) =================
  function renderAssistant() {
    const main = document.getElementById("main");
    main.innerHTML = `
      <div class="segmented">
        <button class="seg-btn ${assistantSubTab==='opps'?'on':''}" data-at="opps">فرصت‌های خودکار</button>
        <button class="seg-btn ${assistantSubTab==='combo'?'on':''}" data-at="combo">ترکیبی</button>
        <button class="seg-btn ${assistantSubTab==='tools'?'on':''}" data-at="tools">ابزار محاسبه</button>
      </div>
      <div id="assistantBody"></div>
    `;
    document.querySelectorAll(".seg-btn[data-at]").forEach(b=>{
      b.onclick = () => { assistantSubTab = b.dataset.at; renderAssistant(); };
    });
    if(assistantSubTab === "opps") renderOppsBody();
    else if(assistantSubTab === "combo") renderComboBody();
    else renderToolsBody();
  }

  function renderOppsBody() {
    const opps = OPP.scanAll();
    document.getElementById("assistantBody").innerHTML = `
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot" style="background:var(--red)"></span> سررسیدهای نزدیک</div><span class="count-pill">${opps.expiries.length}</span></div>
        ${opps.expiries.length ? renderOppList({goodJumps:[],spreads:[], yieldJumps:[], belowTarget:[], expiries:opps.expiries}) : `<div class="empty-state"><span class="es-ic">✅</span>هیچ قراردادی در ۱۵ روز آینده سررسید نمی‌شود.</div>`}
      </div>
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot" style="background:#e08a00"></span> فرصت‌های جامپ خوب</div><span class="count-pill">${opps.goodJumps.length}</span></div>
        ${opps.goodJumps.length ? renderOppList({goodJumps:opps.goodJumps,spreads:[], yieldJumps:[], belowTarget:[], expiries:[]}) : `<div class="empty-state"><span class="es-ic">🔥</span>برای هشدار خودکار، «کاندید جامپ» را روی قراردادهای پرتفوی وارد کنید.</div>`}
      </div>
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot" style="background:var(--green)"></span> تیک‌سود اسپرد</div><span class="count-pill">${opps.spreads.length}</span></div>
        ${opps.spreads.length ? renderOppList({goodJumps:[],spreads:opps.spreads, yieldJumps:[], belowTarget:[], expiries:[]}) : `<div class="empty-state"><span class="es-ic">⚡</span>فعلاً دو قرارداد هم‌اعمال با نقطه تعادل ثبت‌شده ندارید.</div>`}
      </div>
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot" style="background:var(--amber)"></span> نیازمند جامپ بازدهی</div><span class="count-pill">${opps.yieldJumps.length}</span></div>
        ${opps.yieldJumps.length ? renderOppList({goodJumps:[],spreads:[], yieldJumps:opps.yieldJumps, belowTarget:[], expiries:[]}) : `<div class="empty-state"><span class="es-ic">🔁</span>هیچ قراردادی نزدیک سررسید با ارزش زمانی صفر نیست.</div>`}
      </div>
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot" style="background:var(--purple)"></span> زیر آستانه سود هدف</div><span class="count-pill">${opps.belowTarget.length}</span></div>
        ${opps.belowTarget.length ? renderOppList({goodJumps:[],spreads:[], yieldJumps:[], belowTarget:opps.belowTarget, expiries:[]}) : `<div class="empty-state"><span class="es-ic">📈</span>همه قراردادها بالای آستانه هستند.</div>`}
      </div>
    `;
  }

  function renderComboBody() {
    const opps = OPP.scanAll();
    document.getElementById("assistantBody").innerHTML = `
      <div class="panel">
        <div class="panel-title"><div class="panel-title-l"><span class="dot"></span> فرصت خرید ترکیبی روی سهام شما</div><span class="count-pill">${opps.combos.length}</span></div>
        ${opps.combos.length === 0
          ? `<div class="empty-state"><span class="es-ic">🔀</span>برای دیدن مقایسه، روی هر سهم در «پرتفوی» فیلد «اعمال/پرمیوم قرارداد کاندید» را پر کنید.</div>`
          : opps.combos.map(c => `
            <div class="combo-box">
              <div class="cb-symbol">🔀 ${c.position.symbol} <span class="chip ${c.cheaper==='combo'?'bought':'stock'}">${c.cheaper==='combo'?'ترکیبی ارزان‌تر':'خرید مستقیم ارزان‌تر'}</span></div>
              <div class="result-grid">
                <div class="res-card"><div class="lab">هزینه خرید مستقیم</div><div class="val mono">${fmt(c.directCost)}</div></div>
                <div class="res-card"><div class="lab">هزینه ترکیبی (اعمال+پرمیوم)</div><div class="val mono">${fmt(c.comboCost)}</div></div>
              </div>
              <div class="note" style="margin-top:8px;padding-top:0;border-top:none;">${c.message}</div>
            </div>
          `).join("")
        }
      </div>
      <div class="panel">
        <div class="note"><b>فرمول:</b> اگر (اعمال + پرمیوم قرارداد کاندید) کمتر از قیمت خرید مستقیم سهم از بازار باشد، تهیه سهم از طریق قرارداد به‌صرفه‌تر است.</div>
      </div>
    `;
  }

  function renderToolsBody() {
    document.getElementById("assistantBody").innerHTML = `
      <div class="tabs" id="toolTabs">
        <div class="tab ${toolsTab==='panj'?'active':''}" data-tt="panj">مثبت‌پنج</div>
        <div class="tab ${toolsTab==='jy'?'active':''}" data-tt="jy">جامپ بازدهی</div>
        <div class="tab ${toolsTab==='jm'?'active':''}" data-tt="jm">جامپ مدیریتی</div>
        <div class="tab ${toolsTab==='tk'?'active':''}" data-tt="tk">تیک‌سود اسپرد</div>
      </div>
      <div id="toolBody"></div>
    `;
    document.querySelectorAll("#toolTabs .tab").forEach((t) => {
      t.onclick = () => { toolsTab = t.dataset.tt; renderToolsBody(); };
    });
    const body = document.getElementById("toolBody");
    if (toolsTab === "panj") body.innerHTML = toolPanjHtml();
    if (toolsTab === "jy") body.innerHTML = toolJyHtml();
    if (toolsTab === "jm") body.innerHTML = toolJmHtml();
    if (toolsTab === "tk") body.innerHTML = toolTkHtml();
    wireTool(toolsTab);
  }

  function toolPanjHtml(){
    return `
    <div class="panel">
      <div class="panel-title"><span class="dot"></span> ورودی‌ها</div>
      <div class="field-row"><label>اعمال</label><input type="text" id="tp_strike" value="400"></div>
      <div class="field-row"><label>پرمیوم</label><input type="text" id="tp_premium" value="15"></div>
      <div class="field-row"><label>قیمت سهم پایه</label><input type="text" id="tp_spot" value="351"></div>
      <div class="field-row"><label>روز مانده</label><input type="text" id="tp_days" value="30"></div>
      <div class="field-row"><label>کارمزد ٪</label><input type="text" id="tp_fee" value="1.5"></div>
    </div>
    <div class="panel">
      <div class="panel-title"><span class="dot" style="background:var(--green)"></span> نتیجه</div>
      <div class="result-grid">
        <div class="res-card" id="tp_engaged"><div class="lab">سرمایه درگیر</div><div class="val mono">-</div></div>
        <div class="res-card" id="tp_rial"><div class="lab">سود ریالی</div><div class="val mono">-</div></div>
        <div class="res-card hero" id="tp_month"><div class="lab">سود ماهانه</div><div class="val mono">-</div></div>
        <div class="res-card" id="tp_noex"><div class="lab">سود بدون اعمال (ماهانه)</div><div class="val mono">-</div></div>
      </div>
    </div>`;
  }
  function toolJyHtml(){
    return `
    <div class="panel">
      <div class="panel-title"><span class="dot"></span> قرارداد اول (بسته می‌شود)</div>
      <div class="field-row"><label>اعمال اول</label><input type="text" id="tj_strike1" value="400"></div>
      <div class="field-row"><label>پرمیوم آفست</label><input type="text" id="tj_offset" value="3"></div>
      <div class="field-row"><label>روز باقی‌مانده اول</label><input type="text" id="tj_days1" value="5"></div>
    </div>
    <div class="panel">
      <div class="panel-title"><span class="dot" style="background:var(--amber)"></span> قرارداد جدید</div>
      <div class="field-row"><label>پرمیوم دریافتی جدید</label><input type="text" id="tj_premium2" value="22"></div>
      <div class="field-row"><label>روز کل جدید</label><input type="text" id="tj_days2" value="35"></div>
    </div>
    <div class="panel">
      <div class="panel-title"><span class="dot" style="background:var(--green)"></span> نتیجه</div>
      <div class="result-grid">
        <div class="res-card" id="tj_spread"><div class="lab">اختلاف پرمیوم</div><div class="val mono">-</div></div>
        <div class="res-card" id="tj_base"><div class="lab">سهم پایه جدید</div><div class="val mono">-</div></div>
        <div class="res-card hero" id="tj_month"><div class="lab">سود ماهانه</div><div class="val mono">-</div></div>
      </div>
    </div>`;
  }
  function toolJmHtml(){
    return `
    <div class="panel">
      <div class="segmented">
        <button class="seg-btn on" data-mm="down">کاهش اعمال</button>
        <button class="seg-btn" data-mm="up">افزایش اعمال</button>
      </div>
      <div class="field-row"><label>اعمال فعلی</label><input type="text" id="tm_strikeOld" value="400"></div>
      <div class="field-row"><label>پرمیوم بازخرید</label><input type="text" id="tm_premOld" value="60"></div>
      <div class="field-row"><label>اعمال جدید</label><input type="text" id="tm_strikeNew" value="300"></div>
      <div class="field-row"><label>پرمیوم فروش جدید</label><input type="text" id="tm_premNew" value="46"></div>
    </div>
    <div class="panel">
      <div class="panel-title"><span class="dot" style="background:var(--green)"></span> نتیجه</div>
      <div class="result-grid">
        <div class="res-card" id="tm_diff"><div class="lab">اختلاف اعمال</div><div class="val mono">-</div></div>
        <div class="res-card hero" id="tm_verdict"><div class="lab">نتیجه</div><div class="val mono">-</div></div>
      </div>
    </div>`;
  }
  function toolTkHtml(){
    return `
    <div class="panel">
      <div class="field-row"><label>پرمیوم نزدیک</label><input type="text" id="tk_near" value="30"></div>
      <div class="field-row"><label>پرمیوم دور</label><input type="text" id="tk_far" value="30"></div>
      <div class="field-row"><label>نقطه تعادل</label><input type="text" id="tk_eq" value="20"></div>
      <div class="field-row"><label>تعداد قرارداد</label><input type="text" id="tk_qty" value="1000"></div>
    </div>
    <div class="panel">
      <div class="panel-title"><span class="dot" style="background:var(--green)"></span> نتیجه</div>
      <div class="result-grid wide">
        <div class="res-card hero" id="tk_action"><div class="lab">اقدام</div><div class="val mono" style="font-size:16px;">-</div></div>
      </div>
    </div>`;
  }

  function wireTool(tab){
    if(tab==="panj"){
      const ids = ["tp_strike","tp_premium","tp_spot","tp_days","tp_fee"];
      const run = () => {
        const r = F.panjCalc({strike:numVal("tp_strike"),premium:numVal("tp_premium"),spot:numVal("tp_spot"),days:numVal("tp_days"),feePct:numVal("tp_fee")});
        setRes("tp_engaged", fmt(r.engaged), "ریال");
        setRes("tp_rial", fmt(r.rialProfit), "ریال", r.rialProfit>=0?"pos":"neg");
        setRes("tp_month", fmt(r.pctMonth,2)+"٪", "", r.pctMonth>=5?"pos":r.pctMonth>=3?"warn":"neg");
        setRes("tp_noex", fmt(r.noExMonth,2)+"٪", "", r.noExMonth>=3?"pos":"warn");
      };
      ids.forEach(id=>document.getElementById(id).addEventListener("input", run));
      run();
    }
    if(tab==="jy"){
      const ids = ["tj_strike1","tj_offset","tj_days1","tj_premium2","tj_days2"];
      const run = () => {
        const r = F.jumpYieldCalc({strike1:numVal("tj_strike1"),offsetPremium:numVal("tj_offset"),daysLeft1:numVal("tj_days1"),premium2:numVal("tj_premium2"),days2:numVal("tj_days2")});
        setRes("tj_spread", fmt(r.spread), "ریال", r.spread>=18?"pos":"warn");
        setRes("tj_base", fmt(r.newBase), "ریال");
        setRes("tj_month", fmt(r.monthlyPct,2)+"٪", "", r.monthlyPct>=5?"pos":r.monthlyPct>=3?"warn":"neg");
      };
      ids.forEach(id=>document.getElementById(id).addEventListener("input", run));
      run();
    }
    if(tab==="jm"){
      let mode="down";
      document.querySelectorAll(".seg-btn[data-mm]").forEach(b=>{
        b.onclick=()=>{document.querySelectorAll(".seg-btn[data-mm]").forEach(x=>x.classList.remove("on"));b.classList.add("on");mode=b.dataset.mm;run();};
      });
      const ids = ["tm_strikeOld","tm_premOld","tm_strikeNew","tm_premNew"];
      const run = () => {
        const so=numVal("tm_strikeOld"), po=numVal("tm_premOld"), sn=numVal("tm_strikeNew"), pn=numVal("tm_premNew");
        if(mode==="down"){
          const r = F.jumpMgmtDown({strikeOld:so,premiumOld:po,premiumNew:pn});
          setRes("tm_diff", fmt(Math.abs(sn-so)), "ریال");
          setRes("tm_verdict", fmt(r.impliedNewStrike), "اعمال ضمنی");
        } else {
          const r = F.jumpMgmtUp({strikeOld:so,strikeNew:sn,premiumOld:po,premiumNew:pn});
          setRes("tm_diff", fmt(r.strikeDiff), "ریال");
          setRes("tm_verdict", (r.bonus>=0?"+":"")+fmt(r.bonus)+" ریال", "سود اضافه", r.bonus>=0?"pos":"neg");
        }
      };
      ids.forEach(id=>document.getElementById(id).addEventListener("input", run));
      run();
    }
    if(tab==="tk"){
      const ids = ["tk_near","tk_far","tk_eq","tk_qty"];
      const run = () => {
        const r = F.tickSpreadCalc({near:numVal("tk_near"),far:numVal("tk_far"),equilibrium:numVal("tk_eq"),qty:numVal("tk_qty")});
        const labels = {wait:"در نقطه تعادل — صبر کنید", buy_near_sell_far:"بخر نزدیک + بفروش دور", sell_near_buy_far:"بفروش نزدیک + بخر دور"};
        setRes("tk_action", labels[r.action], "", r.action==="wait"?"warn":"pos");
      };
      ids.forEach(id=>document.getElementById(id).addEventListener("input", run));
      run();
    }
  }

  function setRes(id, value, unit, cls){
    const card = document.getElementById(id);
    if(!card) return;
    card.querySelector(".val").textContent = value + (unit? " "+unit : "");
    card.classList.remove("pos","neg","warn");
    if(cls) card.classList.add(cls);
    card.classList.add("pulse");
    setTimeout(()=>card.classList.remove("pulse"), 300);
  }

  // ================= تنظیمات =================
  function renderSettings() {
    const s = DB.getSettings();
    const main = document.getElementById("main");
    main.innerHTML = `
      <div class="panel">
        <div class="panel-title"><span class="dot"></span> ظاهر برنامه</div>
        <div class="settings-row">
          <div><div class="sr-label">حالت نمایش</div><div class="sr-desc">پیش‌فرض روشن — می‌توانید تاریک را هم امتحان کنید</div></div>
          <div class="theme-switch">
            <button data-theme-btn="light" class="${s.theme!=='dark'?'on':''}">☀️ روشن</button>
            <button data-theme-btn="dark" class="${s.theme==='dark'?'on':''}">🌙 تاریک</button>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-title"><span class="dot" style="background:var(--amber)"></span> آستانه‌های هشدار دستیار</div>
        <div class="field-row"><label>حداقل سود ماهانه هدف (٪)</label><input type="text" id="s_minTarget" value="${s.minMonthlyTarget}"></div>
        <div class="field-row"><label>آستانه هشدار «جامپ خوب» (٪)</label><input type="text" id="s_jumpThresh" value="${s.jumpAlertThreshold}"></div>
        <div class="field-row"><label>کارمزد پیش‌فرض (٪)</label><input type="text" id="s_fee" value="${s.feeDefault}"></div>
        <div class="field-row"><label>اندازه پیش‌فرض قرارداد</label><input type="text" id="s_contractSize" value="${s.contractSizeDefault}"></div>
        <div class="btn-row"><button class="btn" id="s_save">ذخیره تنظیمات</button></div>
      </div>

      <div class="panel">
        <div class="panel-title"><span class="dot" style="background:var(--accent)"></span> اتصال بازار زنده</div>
        <div class="note" style="margin-top:0;padding-top:0;border-top:none;">اگر جستجوی نماد یا به‌روزرسانی قیمت جواب نمی‌دهد، اینجا تست کنید تا پیام خطای دقیق را ببینید.</div>
        <div class="btn-row"><button class="btn secondary" id="s_testConn">📡 تست اتصال به TSETMC</button></div>
        <div id="s_testResult"></div>
      </div>

      <div class="panel">
        <div class="panel-title"><span class="dot" style="background:var(--red)"></span> داده‌ها</div>
        <div class="note" style="margin-top:0;padding-top:0;border-top:none;">همه اطلاعات (پرتفوی، معاملات، دیده‌بان) فقط روی همین گوشی ذخیره می‌شود.</div>
        <div class="btn-row"><button class="btn danger" id="s_reset">پاک‌کردن کامل داده‌ها</button></div>
      </div>
    `;

    document.querySelectorAll("[data-theme-btn]").forEach(btn=>{
      btn.onclick = () => {
        const theme = btn.dataset.themeBtn;
        const settings = DB.getSettings();
        settings.theme = theme;
        DB.saveSettings(settings);
        applyTheme(theme);
        renderSettings();
      };
    });

    document.getElementById("s_save").onclick = () => {
      const settings = DB.getSettings();
      settings.minMonthlyTarget = numVal("s_minTarget");
      settings.jumpAlertThreshold = numVal("s_jumpThresh");
      settings.feeDefault = numVal("s_fee");
      settings.contractSizeDefault = numVal("s_contractSize");
      DB.saveSettings(settings);
      renderNav();
      const btn = document.getElementById("s_save");
      btn.textContent = "✓ ذخیره شد";
      setTimeout(()=>{btn.textContent="ذخیره تنظیمات";}, 1500);
    };

    document.getElementById("s_testConn").onclick = async () => {
      const btn = document.getElementById("s_testConn");
      const resBox = document.getElementById("s_testResult");
      btn.textContent = "در حال تست...";
      const r = await TSETMC.testConnection();
      btn.textContent = "📡 تست اتصال به TSETMC";
      if (r.ok) {
        resBox.innerHTML = `<div class="note" style="border-top:none;padding-top:0;color:var(--green);white-space:pre-wrap;">✅ ${r.sample}</div>`;
      } else {
        resBox.innerHTML = `<div class="note" style="border-top:none;padding-top:0;color:var(--red);white-space:pre-wrap;">❌ ${r.error}<br><br>این پیام را دقیقاً کپی و برای بررسی بفرستید.</div>`;
      }
    };

    document.getElementById("s_reset").onclick = () => {
      if(confirm("مطمئنید؟ همه پرتفوی، معاملات و دیده‌بان پاک می‌شود.")){
        localStorage.removeItem("bahari_positions_v1");
        localStorage.removeItem("bahari_trades_v1");
        localStorage.removeItem("bahari_watchlist_v1");
        goTo("dashboard");
      }
    };
  }

  // ================= Modal helper =================
  function showModal(title, bodyHtml) {
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay";
    overlay.id = "modalOverlay";
    overlay.innerHTML = `
      <div class="modal-sheet">
        <div class="modal-header"><h3>${title}</h3><button class="modal-close" id="modalCloseBtn">✕</button></div>
        ${bodyHtml}
      </div>`;
    document.body.appendChild(overlay);
    document.getElementById("modalCloseBtn").onclick = closeModal;
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeModal();
    });
  }
  function closeModal() {
    const m = document.getElementById("modalOverlay");
    if (m) m.remove();
  }

  function val(id) {
    return document.getElementById(id).value.trim();
  }
  function numVal(id) {
    const el = document.getElementById(id);
    if (!el) return 0;
    let v = el.value.replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d));
    v = parseFloat(v);
    return isNaN(v) ? 0 : v;
  }

  function init() {
    const s = DB.getSettings();
    applyTheme(s.theme || "light");
    renderNav();
    startClock();
    goTo("dashboard");
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
      window.Capacitor.Plugins.App.addListener("backButton", handleHardwareBack);
    }
    scheduleExpiryNotifications();
  }

  // ---------------- اعلان واقعی گوشی برای سررسید قراردادها ----------------
  function hashCode(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash) % 1000000;
  }
  async function scheduleExpiryNotifications() {
    if (!(window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications)) return;
    const LN = window.Capacitor.Plugins.LocalNotifications;
    try {
      await LN.requestPermissions();
      const pending = await LN.getPending();
      if (pending && pending.notifications && pending.notifications.length) {
        await LN.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
      }
      const positions = DB.getPositions().filter((p) => p.type === "option" && p.expiryDate);
      const now = Date.now();
      const toSchedule = [];
      positions.forEach((p) => {
        const base = hashCode(p.id);
        const expiryDate = new Date(p.expiryDate + "T09:00:00");
        const twoDaysBefore = new Date(expiryDate.getTime() - 2 * 86400000);
        if (twoDaysBefore.getTime() > now) {
          toSchedule.push({
            id: base * 10 + 1,
            title: "⏱ دستیار آپشن — سررسید نزدیک",
            body: `${p.symbol} (اعمال ${fmt(p.strike)}) دو روز دیگر سررسید می‌شود.`,
            schedule: { at: twoDaysBefore },
          });
        }
        if (expiryDate.getTime() > now) {
          toSchedule.push({
            id: base * 10 + 2,
            title: "🔴 دستیار آپشن — امروز سررسید",
            body: `${p.symbol} (اعمال ${fmt(p.strike)}) امروز سررسید می‌شود!`,
            schedule: { at: expiryDate },
          });
        }
      });
      if (toSchedule.length) await LN.schedule({ notifications: toSchedule });
    } catch (e) {
      console.error("notification schedule error", e);
    }
  }

  return { init, goTo };
})();

document.addEventListener("DOMContentLoaded", APP.init);
