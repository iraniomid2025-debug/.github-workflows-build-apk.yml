/*
  formulas.js
  همه فرمول‌های استخراج‌شده از دوره بهاری (مثبت‌پنج، جامپ، تیک‌سود).
  این فایل هیچ وابستگی به UI ندارد؛ فقط توابع محاسباتی خالص.
*/

const F = (function () {
  // ---------- مثبت پنج ----------
  // ورودی: strike, premium, spot, days, feePct
  function panjCalc({ strike, premium, spot, days, feePct }) {
    const spotWithFee = spot * (1 + feePct / 100);
    const engaged = spotWithFee - premium; // سرمایه درگیر تقریبی
    const rialProfit = strike + premium - spotWithFee;
    const pctTotal = engaged > 0 ? (rialProfit / engaged) * 100 : 0;
    const pctMonth = days > 0 ? (pctTotal / days) * 30 : 0;
    const noExMonth =
      engaged > 0 && days > 0 ? (((premium / engaged) * 100) / days) * 30 : 0;
    return { engaged, rialProfit, pctTotal, pctMonth, noExMonth };
  }

  // ---------- جامپ بازدهی ----------
  // قیمت سهم پایه جدید = اعمال قرارداد اول + پرمیوم آفست
  // روز جدید = روز کل قرارداد دوم − روز باقی‌مانده قرارداد اول
  function jumpYieldCalc({ strike1, offsetPremium, daysLeft1, premium2, days2, feePct = 0 }) {
    const spread = premium2 - offsetPremium;
    const newBase = strike1 + offsetPremium;
    const newDays = days2 - daysLeft1;
    const feeCost = newBase * (feePct / 100);
    const monthlyPct =
      newBase > 0 && newDays > 0
        ? (((spread - feeCost) / newBase) * 100 / newDays) * 30
        : 0;
    return { spread, newBase, newDays, monthlyPct };
  }

  // ---------- جامپ مدیریتی: کاهش اعمال (چالشی) ----------
  // اعمال جدید = اعمال قدیم − اختلاف پرمیوم از‌دست‌رفته
  function jumpMgmtDown({ strikeOld, premiumOld, premiumNew }) {
    const lostPremium = premiumOld - premiumNew; // هزینه
    const impliedNewStrike = strikeOld - lostPremium;
    return { lostPremium, impliedNewStrike };
  }

  // ---------- جامپ مدیریتی: افزایش اعمال ----------
  // سود اضافه = اختلاف اعمال − هزینه خالص (پرمیوم قدیم − پرمیوم جدید)
  function jumpMgmtUp({ strikeOld, strikeNew, premiumOld, premiumNew }) {
    const strikeDiff = strikeNew - strikeOld;
    const netCost = premiumOld - premiumNew;
    const bonus = strikeDiff - netCost;
    return { strikeDiff, netCost, bonus };
  }

  // ---------- تیک‌سود اسپرد (نقطه تعادل) ----------
  function tickSpreadCalc({ near, far, equilibrium, qty, contractSize = 1000 }) {
    const diff = near - far;
    const deviation = diff - equilibrium;
    let action;
    if (Math.abs(deviation) < 0.5) action = "wait"; // نقطه تعادل، صبر کن
    else if (deviation > 0) action = "buy_near_sell_far";
    else action = "sell_near_buy_far";
    const potentialRial = Math.abs(deviation) * qty * contractSize;
    return { diff, deviation, action, potentialRial };
  }

  // ---------- تسویه فیزیکی: پول لازم ----------
  function settlementCash({ qty, contractSize, strike }) {
    return qty * contractSize * strike;
  }

  // ---------- افزایش سرمایه: تعدیل قرارداد ----------
  function capitalIncreaseAdjust({ oldContractSize, priceBefore, priceAfterOpen, oldStrike }) {
    const newContractSize = (priceBefore / priceAfterOpen) * oldContractSize;
    const newStrike = (oldStrike * oldContractSize) / newContractSize;
    return { newContractSize, newStrike };
  }

  // ---------- طبقه‌بندی کلاس قرارداد نسبت به قیمت سهم ----------
  function classify(strike, spot) {
    const diffPct = ((strike - spot) / spot) * 100;
    if (diffPct <= -15) return "A"; // خیلی پایین‌تر (ITM عمیق)
    if (diffPct <= -3) return "B";  // پایین‌تر (ITM ملایم)
    if (diffPct < 3) return "X";    // نزدیک قیمت سهم
    if (diffPct < 15) return "-B";  // بالاتر (OTM ملایم)
    return "-A";                    // خیلی بالاتر (OTM عمیق)
  }

  // ---------- رتبه‌بندی ریسک بر اساس سود ماهانه تقریبی ----------
  function riskBadge(pctMonth) {
    if (pctMonth >= 5) return { label: "کم‌ریسک/مطمئن", cls: "pos" };
    if (pctMonth >= 3) return { label: "قابل‌قبول", cls: "warn" };
    return { label: "زیر آستانه", cls: "neg" };
  }

  return {
    panjCalc,
    jumpYieldCalc,
    jumpMgmtDown,
    jumpMgmtUp,
    tickSpreadCalc,
    settlementCash,
    capitalIncreaseAdjust,
    classify,
    riskBadge,
  };
})();
