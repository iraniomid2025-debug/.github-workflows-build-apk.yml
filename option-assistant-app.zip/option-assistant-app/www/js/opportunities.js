/*
  opportunities.js
  موتور تشخیص فرصت بر اساس موقعیت‌های ثبت‌شده در پرتفوی کاربر (DB.getPositions())
  و آخرین قیمت‌های به‌روزرسانی‌شده (که یا از دیده‌بان زنده یا با ویرایش دستی می‌آید).

  فاز ۱ (این نسخه): تحلیل بین موقعیت‌های خودِ کاربر، نه کل زنجیره بازار
  (چون خزیدن کامل زنجیره آپشن نیاز به نگاشت دقیق InsCode های آپشن دارد که باید
  جداگانه و با تست روی گوشی واقعی تکمیل شود).
*/

const OPP = (function () {
  function daysBetween(dateStr) {
    const target = new Date(dateStr).getTime();
    const now = Date.now();
    return Math.max(0, Math.round((target - now) / 86400000));
  }

  // ۱) فرصت تیک‌سود اسپرد: بین دو قرارداد آپشن هم‌نماد هم‌اعمال با سررسید متفاوت
  function findSpreadOpportunities(positions, settings) {
    const options = positions.filter((p) => p.type === "option");
    const out = [];
    for (let i = 0; i < options.length; i++) {
      for (let j = 0; j < options.length; j++) {
        if (i === j) continue;
        const a = options[i], b = options[j];
        if (a.symbol !== b.symbol || a.strike !== b.strike) continue;
        if (a.expiryDate === b.expiryDate) continue;
        // a = نزدیک‌تر، b = دورتر (بر اساس سررسید)
        if (new Date(a.expiryDate) > new Date(b.expiryDate)) continue;
        if (!a.equilibrium && !b.equilibrium) continue; // نیاز به نقطه تعادل کاربر دارد
        const eq = a.equilibrium || b.equilibrium || 0;
        const res = F.tickSpreadCalc({
          near: a.currentPremium || a.premium,
          far: b.currentPremium || b.premium,
          equilibrium: eq,
          qty: Math.min(a.qty, b.qty),
          contractSize: a.contractSize || settings.contractSizeDefault,
        });
        if (res.action !== "wait") {
          out.push({
            kind: "spread",
            symbol: a.symbol,
            strike: a.strike,
            near: a, far: b,
            ...res,
          });
        }
      }
    }
    return out;
  }

  // ۲) فرصت جامپ بازدهی: قرارداد فروخته‌شده نزدیک سررسید با ارزش زمانی نزدیک صفر
  function findYieldJumpCandidates(positions, settings) {
    const out = [];
    const sold = positions.filter(
      (p) => p.type === "option" && p.side === "sold" && p.expiryDate
    );
    for (const p of sold) {
      const daysLeft = daysBetween(p.expiryDate);
      const premium = p.currentPremium ?? p.premium;
      if (daysLeft <= 5 && premium <= (p.spot || 0) * 0.02) {
        out.push({
          kind: "yield_jump_needed",
          position: p,
          daysLeft,
          message: `قرارداد ${p.symbol} (اعمال ${p.strike}) فقط ${daysLeft} روز مانده و پرمیوم به ${premium} رسیده — وقت آفست و جامپ بازدهی است.`,
        });
      }
    }
    return out;
  }

  // ۳) هشدار سود بدون اعمال زیر آستانه (نیاز به جامپ مدیریتی)
  function findBelowThreshold(positions, settings) {
    const out = [];
    const sold = positions.filter((p) => p.type === "option" && p.side === "sold");
    for (const p of sold) {
      if (!p.spot || !p.strike || !p.expiryDate) continue;
      const days = daysBetween(p.expiryDate);
      if (days <= 0) continue;
      const calc = F.panjCalc({
        strike: p.strike,
        premium: p.currentPremium ?? p.premium,
        spot: p.spot,
        days,
        feePct: settings.feeDefault,
      });
      if (calc.pctMonth < settings.minMonthlyTarget) {
        out.push({
          kind: "below_target",
          position: p,
          calc,
          message: `${p.symbol} اعمال ${p.strike}: سود ماهانه فعلی ${calc.pctMonth.toFixed(
            1
          )}٪ زیر آستانه ${settings.minMonthlyTarget}٪ است — بررسی جامپ افزایش‌اعمال یا مدیریتی.`,
        });
      }
    }
    return out;
  }

  // ۴) هشدار نزدیک‌شدن سررسید (سه سطح فوریت)
  function findExpiryWarnings(positions) {
    const out = [];
    const options = positions.filter((p) => p.type === "option" && p.expiryDate);
    for (const p of options) {
      const days = daysBetween(p.expiryDate);
      let level = null;
      if (days <= 2) level = "critical";
      else if (days <= 7) level = "warning";
      else if (days <= 15) level = "notice";
      if (level) out.push({ kind: "expiry", position: p, daysLeft: days, level });
    }
    return out.sort((a, b) => a.daysLeft - b.daysLeft);
  }

  // ۵) هشدار فرصت جامپ خوب (بالای آستانه دلخواه کاربر، مثلاً ۴٪)
  function findGoodJumpOpportunities(positions, settings) {
    const out = [];
    const sold = positions.filter(
      (p) => p.type === "option" && p.side === "sold" && p.jumpCandidatePremium && p.jumpCandidateDays
    );
    for (const p of sold) {
      const daysLeft1 = daysBetween(p.expiryDate);
      const r = F.jumpYieldCalc({
        strike1: p.strike,
        offsetPremium: p.currentPremium ?? p.premium,
        daysLeft1,
        premium2: p.jumpCandidatePremium,
        days2: p.jumpCandidateDays,
      });
      if (r.monthlyPct >= settings.jumpAlertThreshold) {
        out.push({
          kind: "good_jump",
          position: p,
          calc: r,
          message: `${p.symbol} (اعمال ${p.strike}): جامپ بازدهی الان ~${r.monthlyPct.toFixed(1)}٪ ماهانه می‌دهد — بالای آستانه ${settings.jumpAlertThreshold}٪ شماست.`,
        });
      }
    }
    return out;
  }

  // ۶) فرصت خرید ترکیبی برای سهام نگه‌داشته‌شده (نیاز به قرارداد کاندید دستی روی خودِ موقعیت سهم)
  function findComboOpportunities(positions) {
    const out = [];
    const stocks = positions.filter((p) => p.type === "stock" && p.comboStrike && p.comboPremium);
    for (const s of stocks) {
      const directCost = s.avgPrice;
      const comboCost = Number(s.comboStrike) + Number(s.comboPremium);
      const diff = directCost - comboCost;
      out.push({
        kind: "combo",
        position: s,
        directCost, comboCost, diff,
        cheaper: diff > 0 ? "combo" : "direct",
        message:
          diff > 0
            ? `برای ${s.symbol}، تهیه سهم از طریق قرارداد ترکیبی حدود ${Math.round(diff)} ریال ارزان‌تر از خرید مستقیم است.`
            : `برای ${s.symbol}، خرید مستقیم از بازار حدود ${Math.round(-diff)} ریال ارزان‌تر از معامله ترکیبی فعلی است.`,
      });
    }
    return out;
  }

  function scanAll() {
    const positions = DB.getPositions();
    const settings = DB.getSettings();
    return {
      spreads: findSpreadOpportunities(positions, settings),
      yieldJumps: findYieldJumpCandidates(positions, settings),
      belowTarget: findBelowThreshold(positions, settings),
      expiries: findExpiryWarnings(positions),
      goodJumps: findGoodJumpOpportunities(positions, settings),
      combos: findComboOpportunities(positions),
    };
  }

  return { scanAll, daysBetween };
})();
