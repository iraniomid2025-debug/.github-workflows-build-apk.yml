/*
  storage.js
  لایه ذخیره‌سازی محلی. فعلاً روی localStorage (در Capacitor WebView هم کار می‌کند
  و دائمی است). اگر بعداً خواستیم به Capacitor Preferences یا SQLite مهاجرت کنیم،
  فقط همین فایل باید عوض شود؛ بقیه اپ با DB.* کار می‌کند.
*/

const DB = (function () {
  const KEYS = {
    positions: "bahari_positions_v1",   // سهام + قراردادهای باز
    trades: "bahari_trades_v1",         // دفتر روزانه معاملات
    watchlist: "bahari_watchlist_v1",   // نمادهای زیر نظر برای دیده‌بان زنده
    settings: "bahari_settings_v1",     // تنظیمات کاربر (آستانه سود هدف و ...)
  };

  function _get(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.error("DB read error", key, e);
      return fallback;
    }
  }
  function _set(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
  }
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  // ---------------- Positions ----------------
  function getPositions() {
    return _get(KEYS.positions, []);
  }
  function savePosition(pos) {
    const list = getPositions();
    if (pos.id) {
      const idx = list.findIndex((p) => p.id === pos.id);
      if (idx >= 0) list[idx] = pos;
      else list.push(pos);
    } else {
      pos.id = uid();
      pos.createdAt = Date.now();
      list.push(pos);
    }
    _set(KEYS.positions, list);
    return pos;
  }
  function deletePosition(id) {
    const list = getPositions().filter((p) => p.id !== id);
    _set(KEYS.positions, list);
  }

  // ---------------- Trades (ledger) ----------------
  function getTrades() {
    return _get(KEYS.trades, []).sort((a, b) => b.date.localeCompare(a.date));
  }
  function saveTrade(trade) {
    const list = _get(KEYS.trades, []);
    if (trade.id) {
      const idx = list.findIndex((t) => t.id === trade.id);
      if (idx >= 0) list[idx] = trade;
      else list.push(trade);
    } else {
      trade.id = uid();
      trade.createdAt = Date.now();
      list.push(trade);
    }
    _set(KEYS.trades, list);
    return trade;
  }
  function deleteTrade(id) {
    const list = _get(KEYS.trades, []).filter((t) => t.id !== id);
    _set(KEYS.trades, list);
  }

  // ---------------- Watchlist ----------------
  function getWatchlist() {
    return _get(KEYS.watchlist, []);
  }
  function addWatch(symbolObj) {
    const list = getWatchlist();
    if (!list.find((w) => w.insCode === symbolObj.insCode)) {
      list.push(symbolObj);
      _set(KEYS.watchlist, list);
    }
  }
  function removeWatch(insCode) {
    const list = getWatchlist().filter((w) => w.insCode !== insCode);
    _set(KEYS.watchlist, list);
  }
  function updateWatchPrice(insCode, priceData) {
    const list = getWatchlist();
    const w = list.find((x) => x.insCode === insCode);
    if (w) {
      Object.assign(w, priceData);
      _set(KEYS.watchlist, list);
    }
  }

  // ---------------- Settings ----------------
  function getSettings() {
    return _get(KEYS.settings, {
      theme: "light",            // light | dark
      minMonthlyTarget: 5,       // حداقل سود ماهانه هدف (٪) برای هشدار «زیر آستانه»
      jumpAlertThreshold: 4,     // حداقل سود ماهانه جامپ برای هشدار «فرصت خوب» (٪)
      feeDefault: 1.5,           // کارمزد پیش‌فرض (٪)
      contractSizeDefault: 1000, // اندازه پیش‌فرض قرارداد
    });
  }
  function saveSettings(s) {
    _set(KEYS.settings, s);
  }

  return {
    getPositions, savePosition, deletePosition,
    getTrades, saveTrade, deleteTrade,
    getWatchlist, addWatch, removeWatch, updateWatchPrice,
    getSettings, saveSettings,
    uid,
  };
})();
