/*
  tsetmc.js
  کلاینت اتصال به داده زنده بورس تهران (TSETMC).

  نکته مهم فنی: این درخواست‌ها از نوع fetch مرورگری هستند. اگر اپ را در Capacitor
  (اپ نیتیو اندروید) اجرا کنید، این درخواست‌ها از محدودیت CORS مرورگر عبور می‌کنند
  و باید مستقیماً کار کنند. اگر همین فایل را در یک تب ساده مرورگر (بدون Capacitor)
  باز کنید، ممکن است TSETMC درخواست را به‌خاطر CORS رد کند — این دقیقاً همان مشکلی
  است که قبلاً باهاش مواجه بودید و دلیل اصلی رفتن به سمت اپ کامل است.

  اگر بعد از بیلد روی گوشی هم خطای شبکه گرفتید، این فایل تنها جایی است که باید
  عوض شود (مثلاً تغییر آدرس پایه از cdn.tsetmc.com به www.tsetmc.com یا برعکس).
*/

const TSETMC = (function () {
  const BASE = "https://cdn.tsetmc.com/api";

  async function _fetchJson(url) {
    try {
      const res = await fetch(url, {
        headers: { accept: "application/json" },
      });
      if (!res.ok) {
        lastError = `HTTP ${res.status} ${res.statusText || ""}`.trim();
        return null;
      }
      const text = await res.text();
      try {
        return JSON.parse(text);
      } catch (parseErr) {
        lastError = "پاسخ JSON نامعتبر بود: " + text.slice(0, 120);
        return null;
      }
    } catch (err) {
      lastError = (err && err.message) ? err.message : String(err);
      console.error("TSETMC fetch error:", url, err);
      return null;
    }
  }
  let lastError = null;
  function getLastError(){ return lastError; }

  // تست ساده اتصال - برای دکمه «تست اتصال» در تنظیمات
  async function testConnection() {
    lastError = null;
    const searchData = await _fetchJson(`${BASE}/Instrument/GetInstrumentSearch/${encodeURIComponent("خودرو")}`);
    if (!searchData) return { ok: false, error: "جستجو ناموفق: " + (lastError || "بدون جزئیات") };
    const firstIns = searchData.instrumentSearch && searchData.instrumentSearch[0];
    if (!firstIns) return { ok: true, sample: "جستجو کار کرد ولی نتیجه‌ای نداشت" };

    lastError = null;
    const priceUrl = `${BASE}/ClosingPrice/GetClosingPriceInfo/${firstIns.insCode}`;
    const priceRaw = await _fetchJson(priceUrl);
    if (!priceRaw) {
      return { ok: false, error: `جستجو ✅ کار کرد. دریافت قیمت ❌ ناموفق بود.\nآدرس: ${priceUrl}\nخطا: ${lastError || "بدون جزئیات"}` };
    }
    const priceData = priceRaw.closingPriceInfo || priceRaw;
    return {
      ok: true,
      sample: `جستجو ✅ و قیمت ✅ هر دو پاسخ گرفتند.\nنماد: ${firstIns.lVal18AFC}\nآخرین قیمت: ${priceData.pDrCotVal ?? priceData.pClosing}\nقیمت پایانی: ${priceData.pClosing}\nتغییر: ${priceData.priceChange}٪`,
    };
  }

  // جستجوی نماد بر اساس نام (فارسی یا لاتین)
  async function searchInstrument(term) {
    const data = await _fetchJson(`${BASE}/Instrument/GetInstrumentSearch/${encodeURIComponent(term)}`);
    if (!data || !data.instrumentSearch) return [];
    return data.instrumentSearch.map((x) => ({
      insCode: x.insCode,
      symbol: x.lVal18AFC || x.lVal30 || x.symbol,
      name: x.lVal30 || "",
    }));
  }

  // قیمت لحظه‌ای/پایانی امروز یک نماد با کد داخلی (InsCode)
  async function getClosingPriceInfo(insCode) {
    const raw = await _fetchJson(`${BASE}/ClosingPrice/GetClosingPriceInfo/${insCode}`);
    if (!raw) return null;
    // پاسخ واقعی سرور داخل یک لایه closingPriceInfo بسته‌بندی شده
    const data = raw.closingPriceInfo || raw;
    return {
      insCode,
      lastPrice: data.pDrCotVal ?? data.pClosing ?? null, // آخرین قیمت معامله
      closingPrice: data.pClosing ?? null,                 // قیمت پایانی
      priceYesterday: data.priceYesterday ?? null,
      priceMin: data.priceMin ?? null,
      priceMax: data.priceMax ?? null,
      priceFirst: data.priceFirst ?? null,
      priceChange: data.priceChange ?? null,
      tradeVolume: data.qTotTran5J ?? null,
      updatedAt: Date.now(),
    };
  }

  // به‌روزرسانی گروهی همه نمادهای دیده‌بان (فراخوانی متوالی برای جلوگیری از بلاک‌شدن)
  async function refreshWatchlist(watchArr, onEach) {
    for (const w of watchArr) {
      const info = await getClosingPriceInfo(w.insCode);
      if (info) onEach(w.insCode, info);
      else onEach(w.insCode, { fetchError: lastError || "خطا در دریافت", updatedAt: Date.now() });
      await new Promise((r) => setTimeout(r, 250));
    }
  }

  // شاخص‌های اصلی بازار (برای نمای کلی داشبورد)
  const INDEX_CODES = {
    total: { insCode: "32097828799138957", label: "شاخص کل" },
    equalWeight: { insCode: "67130298613737946", label: "شاخص هم‌وزن" },
  };

  async function getMarketOverview() {
    const results = {};
    for (const key of Object.keys(INDEX_CODES)) {
      const info = await getClosingPriceInfo(INDEX_CODES[key].insCode);
      results[key] = { label: INDEX_CODES[key].label, ...(info || {}) };
    }
    return results;
  }

  // زنجیره آپشن یک نماد پایه (ویژگی جدید — چون فرمت دقیق پاسخ سرور برای این بخش
  // هنوز با داده واقعی تأیید نشده، خروجی خام هم برای اشکال‌زدایی سریع نگه داشته می‌شود)
  async function getOptionChain(underlyingInsCode) {
    const raw = await _fetchJson(`${BASE}/Instrument/GetInstrumentOptionMarketWatch/${underlyingInsCode}`);
    if (!raw) return { ok: false, error: lastError, raw: null, rows: [] };
    // پاسخ‌های TSETMC معمولاً زیر یک کلید با همون اسم متد قرار دارن؛ چند حالت رایج را امتحان می‌کنیم
    const container =
      raw.instrumentOptMarketWatch ||
      raw.optionMarketWatch ||
      raw.instrumentOptionMarketWatch ||
      raw;
    let list = Array.isArray(container) ? container : (container && container.length !== undefined ? container : null);
    if (!list) {
      // پیدا کردن اولین آرایه داخل پاسخ (fallback دفاعی)
      for (const k of Object.keys(raw)) {
        if (Array.isArray(raw[k])) { list = raw[k]; break; }
      }
    }
    if (!list) return { ok: true, raw, rows: [] };
    const rows = list.map((x) => ({
      insCode: x.insCode ?? x.insCodeOption ?? null,
      symbol: x.lVal18AFC ?? x.symbol ?? x.lVal18 ?? "?",
      strike: x.strikePrice ?? x.pRedTran ?? x.strike ?? null,
      expiryDate: x.contractEndDate ?? x.finalExerciseDate ?? x.expiryDate ?? null,
      optionType: x.optionType ?? x.ua ?? null, // 1=Call معمولاً، ولی تأییدنشده
      premium: x.pDrCotVal ?? x.pClosing ?? x.lastPrice ?? null,
      contractSize: x.contractSize ?? null,
      raw: x,
    }));
    return { ok: true, raw, rows };
  }

  return { searchInstrument, getClosingPriceInfo, refreshWatchlist, testConnection, getLastError, getOptionChain };
})();
